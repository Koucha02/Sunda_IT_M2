
region='Sunda_swot';lonmin=112; lonmax=127; latmin=-13; latmax=-3;
generate_etopo_mask(10, [lonmin lonmax], [latmin latmax], -400, './masks/mask_400_Sunda_10.mat');


  % resolution=4;
  % lon_range=[lonmin lonmax];
  % lat_range=[latmin latmax];
  % depth_threshold= -400;
  % output_filename='./masks/mask_400_SCS_swot_10.mat';