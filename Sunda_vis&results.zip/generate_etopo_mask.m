function generate_etopo_mask(resolution, lon_range, lat_range, depth_threshold, output_filename)
% GENERATE_ETOPO_MASK 创建基于ETOPO2地形数据的掩膜矩阵
%   resolution: 网格分辨率（点数/度，如10或20）
%   lon_range:  经度范围 [lon_min, lon_max] (0-360)
%   lat_range:  纬度范围 [lat_min, lat_max] (-90-90)
%   depth_threshold: 等深线阈值（米，负值表示海深）
%   output_filename: 输出文件名（.mat）

%% 参数校验
validateattributes(resolution, {'numeric'}, {'scalar','positive'});
validateattributes(lon_range, {'numeric'}, {'size',[1,2],'>=',0,'<=',360});
validateattributes(lat_range, {'numeric'}, {'size',[1,2],'>=',-90,'<=',90});
validateattributes(depth_threshold, {'numeric'}, {'scalar','<=',0});

%% 生成目标网格
d_lon = 1/resolution;
d_lat = 1/resolution;
lon_vec = lon_range(1):d_lon:lon_range(2);
lat_vec = lat_range(1):d_lat:lat_range(2);
% [target_lon, target_lat] = meshgrid(lon_vec, lat_vec);

%% 读取ETOPO2数据
etopo_file = 'E:/Matlab2024/m_map1.4/m_map/data/ETOPO2v2c_f4.nc';

% 获取原始数据范围
etopo_lon = ncread(etopo_file, 'x'); % 0-360
etopo_lat = ncread(etopo_file, 'y'); % -90-90
etopo_z = ncread(etopo_file, 'z');     % 维度为 [lon×lat]

%% 数据切片处理
% 查找经度索引
lon_idx = find(etopo_lon >= lon_range(1) & etopo_lon <= lon_range(2));
% % 查找纬度索引（注意ETOPO纬度顺序为北到南）
% lat_idx = find(flip(etopo_lat) >= lat_range(1) & flip(etopo_lat) <= lat_range(2));
lat_idx = find(etopo_lat >= lat_range(1) & etopo_lat <= lat_range(2));

% 提取数据子集
sub_z = etopo_z(lon_idx, lat_idx);
sub_lon = etopo_lon(lon_idx);
% sub_lat = flip(etopo_lat(lat_idx)); % 转换为南到北
sub_lat = etopo_lat(lat_idx);

%% 双线性插值
% 创建ETOPO网格
[etopo_lon_grid, etopo_lat_grid] = meshgrid(sub_lon, sub_lat);

[target_lon, target_lat] = meshgrid(lon_vec, lat_vec);

% 执行插值（注意维度转置）
interp_z = interp2(sub_lon, sub_lat, sub_z', ...
                   target_lon, target_lat, 'linear');

%% 生成掩膜矩阵
mask = ones(size(interp_z));
mask(interp_z > depth_threshold) = NaN; % 高于阈值置为NaN

%% 保存结果
save(output_filename, 'mask', 'lon_vec', 'lat_vec');
disp(['Mask saved to ' output_filename]);

end
