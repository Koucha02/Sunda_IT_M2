% clear all
region='Sunda';lonmin=112;lonmax=127;latmin=-13;latmax=-3;

load Sunda_result10_180.mat
load Sunda_flux.mat
lats = [latmin,latmax];
lons = [lonmin,lonmax];
it = 1;%（M2,S2,K1,O1）
angles = [0 360 0 360];

cl = 15;
sizcale = 5000;
mr = 4;
m = 2;

Nr = 2;
Nc = 2;
smooth2aopen = 0;
bandpassopen = 0;
phase = 0;

deta=1/mr;
grid_lat=lats(1):deta:lats(2);
grid_lon=lons(1):deta:lons(2);
[X,Y]=meshgrid(grid_lon,grid_lat);

detab=1/m;
grid_latb=lats(1):detab:lats(2);
grid_lonb=lons(1):detab:lons(2);
[Xb,Yb]=meshgrid(grid_lonb,grid_latb);

figure('position',[300,300,1000,800])
m_proj('miller','long',lons,'lat',lats);
hold on

%choose tide
ampn=squeeze(Gamp(:,:,it,:))*1000; %unit:m to mm
thetan=squeeze(Gtheta(:,:,it,:));
phan=squeeze(Gpha(:,:,it,:));
F_m2n=squeeze(F_m2(:,:,it,:));

num=double((thetan>=angles(1) & thetan<=angles(2)) | (thetan>=angles(3) & thetan<=angles(4)));
Nthetan=thetan.*num;
Nampn=ampn.*num;
Nphan=phan.*num;
NF_m2=F_m2n.*num;

NF_m2(NF_m2>1e4)=nan;
theamp=Nampn.*cos(Nphan*pi/180+phase);
fluxx=NF_m2.*cos(Nthetan*pi/180);
fluxy=NF_m2.*sin(Nthetan*pi/180);

path_mask=strcat('./masks/mask_400_',region,'_',num2str(mr),'.mat');
load(path_mask);
mask=mask';

Ntheamp=nansum(theamp,3);
Nfluxx=nansum(fluxx,3).*mask;
Nfluxy=nansum(fluxy,3).*mask;

idx = abs(Ntheamp) > 60;
Ntheamp(idx) = NaN;
Ntheamp = fillmissing(Ntheamp,'linear');

% filter
Ntheamp = filt2(Ntheamp,0.1*111,[90 180],'bp'); 
% Ntheamp = filt2(Ntheamp,0.1*111,[230 390],'bp'); 
Ntheamp=Ntheamp.*mask;

pc = m_pcolor(X,Y,Ntheamp'); 
set(pc,'linestyle','none');
colormap(othercolor('RdBu11'));
caxis([-cl cl]);
c=colorbar;
c.FontSize= 15;
title(c, 'SSH (mm)', 'FontSize', 15);
xp=xlabel('Longitude', 'FontSize', 16, 'FontWeight', 'bold');
yp=ylabel('Latitude', 'FontSize', 16, 'FontWeight', 'bold');
yp.Position(1) = yp.Position(1)+0.002;
hold on
m_quiver(Xb,Yb,Nfluxx(1:mr/m:end,1:mr/m:end)'/sizcale,Nfluxy(1:mr/m:end,1:mr/m:end)'/sizcale,0,'color','k','LineWidth',1);

[~,H]=m_etopo2('contour',[-400 -400]);
H.LineColor='k';
H.LineWidth=1;

m_gshhs_i('patch',[.5 .5 .5]);
m_grid('tickdir', 'in', 'linewi', 3, 'XTick', lons(1)-1:5:lons(2), 'YTick', lats(1):5:lats(2), ...
   'XaxisLocation', 'bottom', 'YaxisLocation', 'left','FontSize',15);

lat_marker = 6;
lon_marker = 144;
width_marker = 2.7;
height_marker = 1.5;
m_rectangle(lon_marker,lat_marker,width_marker,height_marker,0,'Curvature',0,'FaceColor',[1 1 1],'EdgeColor','k','LineWidth',1)
m_quiver(lon_marker+1,lat_marker+1.2,1,0,0,'color','k','LineWidth',1.5,'MaxHeadSize',1);
m_text(lon_marker+0.5,lat_marker+0.5,[num2str(sizcale/1e3),' kW/m'],'FontSize',10)
